package com.example.anagramcheckerapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnagramCheckerApplicationTests {

    @Test
    void contextLoads() {
    }

}
