package com.example.anagramcheckerapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnagramCheckerApplication {

    public static void main(String[] args) {
        SpringApplication.run(AnagramCheckerApplication.class, args);
    }
}

