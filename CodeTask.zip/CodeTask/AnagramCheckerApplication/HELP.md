# Getting Started

### Code Task Beyonnex

Write a Java program that checks if two texts are anagrams of each other.

Please use the english wikipedia entry for the definition of anagram.

The solution has to be in Java or Kotlin.

Feel free to use your favourite IDE, unit test frameworks, automated build system etc.

You can prioritize however you like (performance, readability, extensibility, …).

Googling is a good thing :)

For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/3.1.1/maven-plugin/reference/html/)
* [Create an OCI image](https://docs.spring.io/spring-boot/docs/3.1.1/maven-plugin/reference/html/#build-image)
* [Spring Boot DevTools](https://docs.spring.io/spring-boot/docs/3.1.1/reference/htmlsingle/#using.devtools)

